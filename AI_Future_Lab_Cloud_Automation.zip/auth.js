require("dotenv").config();
const http = require("http");
const { google } = require("googleapis");
const redirect = "http://localhost:3000/oauth2callback";

(async () => {
  const id = process.env.YOUTUBE_CLIENT_ID;
  const secret = process.env.YOUTUBE_CLIENT_SECRET;
  if (!id || !secret) throw new Error("Set YOUTUBE_CLIENT_ID and YOUTUBE_CLIENT_SECRET in .env first.");
  const oauth = new google.auth.OAuth2(id, secret, redirect);
  const url = oauth.generateAuthUrl({
    access_type: "offline", prompt: "consent",
    scope: ["https://www.googleapis.com/auth/youtube.upload"]
  });
  const server = http.createServer(async (req, res) => {
    if (!req.url.startsWith("/oauth2callback")) {
      res.writeHead(404); return res.end("Not found");
    }
    const code = new URL(req.url, redirect).searchParams.get("code");
    if (!code) {
      res.writeHead(400); return res.end("Authorization code missing. Close this tab and retry.");
    }
    try {
      const { tokens } = await oauth.getToken(code);
      if (!tokens.refresh_token) throw new Error("No refresh token returned. Revoke app access in Google Account and run npm run auth again.");
      console.log("\\nYOUTUBE_REFRESH_TOKEN (copy this into GitHub Secret):\\n" + tokens.refresh_token);
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end("<h2>AI Future Lab connected successfully.</h2><p>You can close this tab and copy the refresh token from your terminal.</p>");
      server.close();
    } catch (e) {
      res.writeHead(500); res.end("Token exchange failed: " + e.message);
      console.error(e.message); server.close();
    }
  });
  server.listen(3000, "127.0.0.1", () => {
    console.log("\\nOpen this URL and choose the Google account that owns AI Future Lab:\\n\\n" + url + "\\n");
    console.log("After approval, this local page will confirm the connection.");
  });
})().catch(e => { console.error(e.message); process.exit(1); });
