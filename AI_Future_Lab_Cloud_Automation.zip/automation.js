require("dotenv").config();
const fs = require("fs");
const path = require("path");
const https = require("https");
const { execFile } = require("child_process");
const { promisify } = require("util");
const sharp = require("sharp");
const googleTTS = require("google-tts-api");
const { google } = require("googleapis");

const execFileAsync = promisify(execFile);
const ROOT = __dirname;
const CONFIG = require("./config.json");
const OUT = path.join(ROOT, "output");
const HISTORY = path.join(ROOT, "data", "history.json");

function required(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing environment variable: ${name}`);
  return v;
}
function safeFile(s) {
  return String(s).replace(/[^a-z0-9-_]/gi, "_").slice(0, 60);
}
function escapeXml(s) {
  return String(s).replace(/[<>&'"]/g, c => ({
    "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
  }[c]));
}
function loadHistory() {
  try { return JSON.parse(fs.readFileSync(HISTORY, "utf8")); }
  catch { return []; }
}
function saveHistory(history) {
  fs.mkdirSync(path.dirname(HISTORY), { recursive: true });
  fs.writeFileSync(HISTORY, JSON.stringify(history.slice(-100), null, 2));
}
async function geminiGenerate(history) {
  const apiKey = required("GEMINI_API_KEY");
  const recent = history.slice(-20).map(x => x.topic).join("; ");
  const prompt = `You are the senior Shorts producer for ${CONFIG.channelName}.
Create ONE original, useful, accurate YouTube Short for a US/global English-speaking audience.
Channel niche: AI tools, AI agents, automation, Gemini, creator productivity.
Avoid these recent topics: ${recent || "none"}.
Make it evergreen if you cannot verify a current claim. Do not invent prices, features, release dates, or statistics.
Return ONLY valid JSON with this exact shape:
{
 "topic":"short topic",
 "title":"YouTube title under 85 characters",
 "description":"2-3 sentence description with a natural call to action",
 "hashtags":["#AI","#AITools","#Shorts"],
 "tags":["AI tools","AI automation","..."],
 "hook":"one punchy opening line",
 "script":"90-115 spoken English words, clear and conversational, no markdown",
 "scenes":[
   {"headline":"2-5 WORDS","caption":"short supporting phrase"}
 ]
}
Provide exactly ${CONFIG.sceneCount} scenes. The script must be original and not claim guaranteed results. End the script with a brief follow request for AI Future Lab.`;
  const url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(apiKey);
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.85, responseMimeType: "application/json" }
    })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(`Gemini API ${response.status}: ${JSON.stringify(data).slice(0, 700)}`);
  const raw = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("");
  if (!raw) throw new Error("Gemini returned an empty response.");
  const result = JSON.parse(raw.replace(/^```json\s*/i, "").replace(/```$/, "").trim());
  if (!result.script || !result.title || !Array.isArray(result.scenes) || result.scenes.length !== CONFIG.sceneCount) {
    throw new Error("Gemini response did not match the required content structure.");
  }
  result.hashtags = Array.isArray(result.hashtags) ? result.hashtags : ["#AI", "#AITools", "#Shorts"];
  result.tags = Array.isArray(result.tags) ? result.tags : ["AI", "AI tools", "AI automation"];
  return result;
}
function download(url, destination) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destination);
    https.get(url, response => {
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
        file.close(); fs.unlink(destination, () => {});
        return download(response.headers.location, destination).then(resolve, reject);
      }
      if (response.statusCode !== 200) {
        file.close(); fs.unlink(destination, () => {});
        return reject(new Error(`Audio download failed: HTTP ${response.statusCode}`));
      }
      response.pipe(file);
      file.on("finish", () => file.close(resolve));
    }).on("error", err => { fs.unlink(destination, () => {}); reject(err); });
  });
}
async function makeVoice(script, base) {
  const urls = googleTTS.getAllAudioUrls(script, {
    lang: "en-US", slow: false, host: "https://translate.google.com"
  });
  const parts = [];
  for (let i = 0; i < urls.length; i++) {
    const p = `${base}_voice_${i}.mp3`;
    await download(urls[i].url, p);
    parts.push(p);
  }
  const list = `${base}_audio_list.txt`;
  fs.writeFileSync(list, parts.map(p => `file '${path.basename(p)}'`).join("\n"));
  const audio = `${base}.mp3`;
  await execFileAsync("ffmpeg", ["-y", "-f", "concat", "-safe", "0", "-i", list, "-c", "copy", audio]);
  return { audio, parts, list };
}
async function makeSlide(scene, index, total, file, title) {
  const headline = escapeXml(String(scene.headline || "AI FUTURE").toUpperCase());
  const caption = escapeXml(String(scene.caption || ""));
  const top = index === 0 ? "AI FUTURE LAB" : `AI FUTURE LAB  •  ${String(index + 1).padStart(2, "0")}/${total}`;
  const svg = `<svg width="1080" height="1920" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#030914"/><stop offset="0.55" stop-color="#0A1D39"/><stop offset="1" stop-color="#10102D"/></linearGradient>
    <radialGradient id="glow"><stop offset="0" stop-color="#00D9FF" stop-opacity=".38"/><stop offset="1" stop-color="#00D9FF" stop-opacity="0"/></radialGradient>
    <filter id="blur"><feGaussianBlur stdDeviation="35"/></filter>
  </defs>
  <rect width="1080" height="1920" fill="url(#bg)"/>
  <circle cx="860" cy="350" r="330" fill="url(#glow)" filter="url(#blur)"/>
  <circle cx="160" cy="1540" r="360" fill="#654BFF" opacity=".15" filter="url(#blur)"/>
  <g stroke="#0B9EC8" stroke-opacity=".18" stroke-width="2">
    ${Array.from({length:15},(_,i)=>`<path d="M ${i*80} 0 V1920"/>`).join("")}
    ${Array.from({length:26},(_,i)=>`<path d="M0 ${i*80} H1080"/>`).join("")}
  </g>
  <rect x="68" y="92" width="944" height="2" fill="#00D9FF" opacity=".8"/>
  <text x="80" y="165" fill="#7DEBFF" font-family="Arial" font-size="35" font-weight="700" letter-spacing="5">${top}</text>
  <rect x="80" y="700" width="12" height="390" rx="6" fill="#00D9FF"/>
  <text x="130" y="835" fill="#F4FAFF" font-family="Arial" font-size="88" font-weight="800">${headline.split(" ").slice(0,2).join(" ")}</text>
  <text x="130" y="940" fill="#F4FAFF" font-family="Arial" font-size="88" font-weight="800">${headline.split(" ").slice(2,4).join(" ")}</text>
  <foreignObject x="130" y="1030" width="820" height="300"><div xmlns="http://www.w3.org/1999/xhtml" style="font-family:Arial,sans-serif;color:#BCEFFF;font-size:43px;line-height:1.3;font-weight:500">${caption}</div></foreignObject>
  <rect x="80" y="1650" width="920" height="3" fill="#00D9FF" opacity=".55"/>
  <text x="80" y="1730" fill="#FFFFFF" font-family="Arial" font-size="30" letter-spacing="3">UNDERSTAND AI. USE AI. STAY AHEAD.</text>
  <text x="80" y="1810" fill="#65DFFF" font-family="Arial" font-size="28">${escapeXml(String(title).slice(0, 48))}</text>
  </svg>`;
  await sharp(Buffer.from(svg)).png().toFile(file);
}
async function buildVideo(item, slug) {
  fs.mkdirSync(OUT, { recursive: true });
  const base = path.join(OUT, slug);
  const { audio, parts, list } = await makeVoice(item.script, base);
  const probe = await execFileAsync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", audio]);
  const duration = Math.max(18, Number(probe.stdout.trim()) || 40);
  const perSlide = duration / item.scenes.length;
  const slideFiles = [];
  for (let i = 0; i < item.scenes.length; i++) {
    const slide = `${base}_slide_${i}.png`;
    await makeSlide(item.scenes[i], i, item.scenes.length, slide, item.title);
    slideFiles.push(slide);
  }
  const concatFile = `${base}_slides.txt`;
  const concatLines = [];
  slideFiles.forEach((p, i) => {
    concatLines.push(`file '${path.basename(p)}'`);
    concatLines.push(`duration ${perSlide.toFixed(3)}`);
  });
  concatLines.push(`file '${path.basename(slideFiles[slideFiles.length - 1])}'`);
  fs.writeFileSync(concatFile, concatLines.join("\n"));
  const video = `${base}.mp4`;
  await execFileAsync("ffmpeg", [
    "-y", "-f", "concat", "-safe", "0", "-i", concatFile, "-i", audio,
    "-vf", "scale=1080:1920,fps=30,format=yuv420p",
    "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
    "-c:a", "aac", "-b:a", "128k", "-shortest", "-movflags", "+faststart", video
  ]);
  return { video, cleanup: [...parts, list, audio, concatFile, ...slideFiles] };
}
async function uploadToYouTube(item, videoPath) {
  const oauth = new google.auth.OAuth2(
    required("YOUTUBE_CLIENT_ID"),
    required("YOUTUBE_CLIENT_SECRET")
  );
  oauth.setCredentials({ refresh_token: required("YOUTUBE_REFRESH_TOKEN") });
  const youtube = google.youtube({ version: "v3", auth: oauth });
  const privacy = process.env.YOUTUBE_PRIVACY || "unlisted";
  if (!["private", "unlisted", "public"].includes(privacy)) throw new Error("YOUTUBE_PRIVACY must be private, unlisted, or public.");
  const description = `${item.description}\n\n${item.hashtags.join(" ")}\n\nSubscribe to AI Future Lab for practical AI tools, agents and automation.`;
  const response = await youtube.videos.insert({
    part: ["snippet", "status"],
    requestBody: {
      snippet: {
        title: item.title.slice(0, 100),
        description: description.slice(0, 5000),
        tags: item.tags.slice(0, 30),
        categoryId: process.env.YOUTUBE_CATEGORY_ID || "28",
        defaultLanguage: process.env.YOUTUBE_DEFAULT_LANGUAGE || "en"
      },
      status: {
        privacyStatus: privacy,
        selfDeclaredMadeForKids: false
      }
    },
    media: { body: fs.createReadStream(videoPath) }
  });
  return `https://youtube.com/shorts/${response.data.id}`;
}
async function run() {
  for (const name of ["GEMINI_API_KEY", "YOUTUBE_CLIENT_ID", "YOUTUBE_CLIENT_SECRET", "YOUTUBE_REFRESH_TOKEN"]) required(name);
  const history = loadHistory();
  const item = await geminiGenerate(history);
  const slug = `${new Date().toISOString().slice(0,10)}_${safeFile(item.topic)}`;
  const built = await buildVideo(item, slug);
  const url = await uploadToYouTube(item, built.video);
  history.push({ date: new Date().toISOString(), topic: item.topic, title: item.title, url });
  saveHistory(history);
  fs.writeFileSync(path.join(OUT, `${slug}.json`), JSON.stringify({ ...item, url }, null, 2));
  console.log(`SUCCESS: ${url}`);
  console.log(`TITLE: ${item.title}`);
  console.log(`TOPIC: ${item.topic}`);
  // Keep final MP4 and JSON as GitHub Actions artifacts; remove temporary media only.
  for (const p of built.cleanup) { try { fs.unlinkSync(p); } catch {} }
}
run().catch(err => { console.error("AUTOMATION FAILED:", err.message); process.exit(1); });
